import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Generate API Key
const generateApiKey = () => {
  if (window.crypto && window.crypto.randomUUID) {
    return window.crypto.randomUUID();
  }
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
};

interface User {
  email: string;
  name: string;
  qrisStatic?: string;
  apiKey?: string;
  role?: 'admin' | 'agen';
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string, role?: 'admin' | 'agen') => Promise<boolean>;
  logout: () => void;
  loading: boolean;
  updateQRIS: (qrisStatic: string) => void;
  getUserQRIS: () => string | null;
  getApiKey: () => string | null;
  // Admin
  getAllUsers: () => User[];
  deleteUser: (email: string) => void;
  updateUserQRIS: (email: string, qrisStatic: string) => void;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch {
        setUser(null);
      }
    }
    setLoading(false);
  }, []);

  // ===== REGISTER =====
  const register = async (
    name: string,
    email: string,
    password: string,
    role: 'admin' | 'agen' = 'agen'
  ): Promise<boolean> => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    if (users.find((u: any) => u.email === email)) {
      alert('Email sudah terdaftar!');
      return false;
    }
    const apiKey = generateApiKey();
    const newUser = { name, email, password, qrisStatic: '', apiKey, role };
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    // Auto login
    const userData = { name, email, qrisStatic: '', apiKey, role };
    localStorage.setItem('user', JSON.stringify(userData));
    setUser(userData);
    return true;
  };

  // ===== LOGIN =====
  const login = async (email: string, password: string): Promise<boolean> => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const found = users.find((u: any) => u.email === email && u.password === password);
    if (!found) {
      alert('Email atau password salah!');
      return false;
    }
    const userData: User = {
      name: found.name,
      email: found.email,
      qrisStatic: found.qrisStatic || '',
      apiKey: found.apiKey || '',
      role: found.role || 'agen'
    };
    localStorage.setItem('user', JSON.stringify(userData));
    setUser(userData);
    return true;
  };

  const logout = () => {
    localStorage.removeItem('user');
    setUser(null);
  };

  const updateQRIS = (qrisStatic: string) => {
    if (!user) return;
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const index = users.findIndex((u: any) => u.email === user.email);
    if (index !== -1) {
      users[index].qrisStatic = qrisStatic;
      localStorage.setItem('users', JSON.stringify(users));
      const updatedUser = { ...user, qrisStatic };
      localStorage.setItem('user', JSON.stringify(updatedUser));
      setUser(updatedUser);
    }
  };

  const getUserQRIS = (): string | null => {
    if (!user) return null;
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const found = users.find((u: any) => u.email === user.email);
    return found ? found.qrisStatic || null : null;
  };

  const getApiKey = (): string | null => {
    if (!user) return null;
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const found = users.find((u: any) => u.email === user.email);
    return found ? found.apiKey || null : null;
  };

  // ===== ADMIN FUNCTIONS =====
  const getAllUsers = (): User[] => {
    return JSON.parse(localStorage.getItem('users') || '[]');
  };

  const deleteUser = (email: string) => {
    if (email === user?.email) {
      alert('Tidak bisa menghapus akun sendiri!');
      return;
    }
    let users = JSON.parse(localStorage.getItem('users') || '[]');
    users = users.filter((u: any) => u.email !== email);
    localStorage.setItem('users', JSON.stringify(users));
  };

  const updateUserQRIS = (email: string, qrisStatic: string) => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const index = users.findIndex((u: any) => u.email === email);
    if (index !== -1) {
      users[index].qrisStatic = qrisStatic;
      localStorage.setItem('users', JSON.stringify(users));
    }
  };

  const isAdmin = user?.role === 'admin';

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        register,
        logout,
        loading,
        updateQRIS,
        getUserQRIS,
        getApiKey,
        getAllUsers,
        deleteUser,
        updateUserQRIS,
        isAdmin
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth harus digunakan di dalam AuthProvider');
  return context;
};