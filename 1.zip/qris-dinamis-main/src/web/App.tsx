import { Routes, Route } from 'react-router-dom';
import { ProtectedRoute } from './pages/ProtectedRoute';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { QRISMain } from './pages/QRISMain';
import { DepositPage } from './pages/DepositPage';
import { AdminPage } from './pages/AdminPage'; // <-- IMPORT

export default function App() {
  return (
    <Routes>
      {/* Halaman publik (tidak perlu login) */}
      <Route path="/deposit" element={<DepositPage />} />
      
      {/* Halaman login & register */}
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      
      {/* Halaman admin (harus login & role admin) */}
      <Route
        path="/admin"
        element={
          <ProtectedRoute>
            <AdminPage />
          </ProtectedRoute>
        }
      />
      
      {/* Halaman utama (harus login) - DILETAKKAN DI BAWAH */}
      <Route
        path="/*"
        element={
          <ProtectedRoute>
            <QRISMain />
          </ProtectedRoute>
        }
      />
    </Routes>
  );
}