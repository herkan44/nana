import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { validateQRIS } from '@core/index';
import { Header } from '../components/Header';
import { Footer } from '../components/Footer';

export const AdminPage = () => {
  const { user, getAllUsers, deleteUser, updateUserQRIS, isAdmin, logout } = useAuth();
  const [users, setUsers] = useState<any[]>([]);
  const [editingEmail, setEditingEmail] = useState<string | null>(null);
  const [editQRIS, setEditQRIS] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [addStatus, setAddStatus] = useState('');

  const loadUsers = () => {
    setUsers(getAllUsers());
  };

  useEffect(() => {
    loadUsers();
  }, []);

  // Redirect if not admin
  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-950">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red-600">Akses Ditolak</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">Hanya admin yang bisa mengakses halaman ini.</p>
        </div>
      </div>
    );
  }

  const handleDelete = (email: string) => {
    if (confirm(`Yakin ingin menghapus agen ${email}?`)) {
      deleteUser(email);
      loadUsers();
    }
  };

  const handleEditQRIS = (email: string, currentQRIS: string) => {
    setEditingEmail(email);
    setEditQRIS(currentQRIS || '');
  };

  const handleSaveQRIS = () => {
    if (!editingEmail) return;
    const validation = validateQRIS(editQRIS.trim());
    if (!validation.valid) {
      alert('QRIS tidak valid: ' + validation.errors.join(', '));
      return;
    }
    updateUserQRIS(editingEmail, editQRIS.trim());
    setEditingEmail(null);
    loadUsers();
    alert('✅ QRIS berhasil diupdate!');
  };

  const handleAddUser = () => {
    if (!newName || !newEmail || !newPassword) {
      setAddStatus('Semua field harus diisi!');
      return;
    }
    // Cek email duplikat
    const existing = users.find((u: any) => u.email === newEmail);
    if (existing) {
      setAddStatus('Email sudah terdaftar!');
      return;
    }
    // Simpan user baru
    const newUser = {
      name: newName,
      email: newEmail,
      password: newPassword,
      qrisStatic: '',
      apiKey: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15),
      role: 'agen'
    };
    const updated = [...users, newUser];
    localStorage.setItem('users', JSON.stringify(updated));
    setAddStatus('✅ Agen berhasil dibuat!');
    setNewName('');
    setNewEmail('');
    setNewPassword('');
    setShowAddForm(false);
    loadUsers();
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-950">
      <Header />
      <main className="flex-1 w-full max-w-6xl mx-auto px-4 py-8 space-y-6">
        <div className="flex justify-between items-center bg-white dark:bg-gray-900 p-4 rounded-lg shadow">
          <div>
            <h1 className="text-2xl font-bold">Panel Admin QRIS</h1>
            <p className="text-sm text-gray-500">👋 Halo, {user?.name} (Admin)</p>
          </div>
          <button
            onClick={logout}
            className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg text-sm"
          >
            Logout
          </button>
        </div>

        {/* Tombol Tambah Agen */}
        <div className="bg-white dark:bg-gray-900 p-4 rounded-lg shadow">
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm"
          >
            + Tambah Agen Baru
          </button>

          {showAddForm && (
            <div className="mt-4 p-4 border rounded-lg bg-gray-50 dark:bg-gray-800 space-y-3">
              <h3 className="font-semibold">Buat Agen Baru</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <input
                  type="text"
                  placeholder="Nama Agen"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="px-3 py-2 border rounded dark:bg-gray-700"
                />
                <input
                  type="email"
                  placeholder="Email Agen"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  className="px-3 py-2 border rounded dark:bg-gray-700"
                />
                <input
                  type="text"
                  placeholder="Password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="px-3 py-2 border rounded dark:bg-gray-700"
                />
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleAddUser}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm"
                >
                  Simpan Agen
                </button>
                <button
                  onClick={() => setShowAddForm(false)}
                  className="px-4 py-2 bg-gray-400 hover:bg-gray-500 text-white rounded-lg text-sm"
                >
                  Batal
                </button>
              </div>
              {addStatus && <p className="text-sm">{addStatus}</p>}
            </div>
          )}
        </div>

        {/* Daftar Agen */}
        <div className="bg-white dark:bg-gray-900 rounded-lg shadow overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 dark:bg-gray-800">
                <tr>
                  <th className="px-4 py-3 text-left">#</th>
                  <th className="px-4 py-3 text-left">Nama</th>
                  <th className="px-4 py-3 text-left">Email</th>
                  <th className="px-4 py-3 text-left">API Key</th>
                  <th className="px-4 py-3 text-left">QRIS Statis</th>
                  <th className="px-4 py-3 text-left">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {users.filter((u: any) => u.role !== 'admin').map((u: any, i: number) => (
                  <tr key={i} className="border-t dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800/50">
                    <td className="px-4 py-3">{i + 1}</td>
                    <td className="px-4 py-3 font-medium">{u.name}</td>
                    <td className="px-4 py-3">{u.email}</td>
                    <td className="px-4 py-3">
                      <code className="bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded text-xs break-all">
                        {u.apiKey || '-'}
                      </code>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(u.apiKey || '');
                          alert('✅ API Key disalin!');
                        }}
                        className="ml-2 text-blue-500 hover:text-blue-700 text-xs"
                      >
                        Copy
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      {u.qrisStatic ? (
                        <span className="text-green-600 text-xs">✓ Ada ({u.qrisStatic.length} chars)</span>
                      ) : (
                        <span className="text-red-500 text-xs">Belum upload</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1">
                        <button
                          onClick={() => handleEditQRIS(u.email, u.qrisStatic)}
                          className="px-2 py-1 bg-yellow-500 hover:bg-yellow-600 text-white rounded text-xs"
                        >
                          Edit QRIS
                        </button>
                        <button
                          onClick={() => handleDelete(u.email)}
                          className="px-2 py-1 bg-red-500 hover:bg-red-600 text-white rounded text-xs"
                        >
                          Hapus
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {users.filter((u: any) => u.role !== 'admin').length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-gray-500">
                      Belum ada agen. Klik "Tambah Agen Baru" untuk membuat.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal Edit QRIS */}
        {editingEmail && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-900 rounded-lg p-6 max-w-lg w-full">
              <h3 className="text-lg font-bold mb-2">Edit QRIS Statis</h3>
              <p className="text-sm text-gray-500 mb-3">Agen: <strong>{editingEmail}</strong></p>
              <textarea
                value={editQRIS}
                onChange={(e) => setEditQRIS(e.target.value)}
                rows={4}
                className="w-full p-3 border rounded dark:bg-gray-800 font-mono text-sm"
                placeholder="Tempel QRIS statis di sini..."
              />
              <div className="flex gap-2 mt-3">
                <button
                  onClick={handleSaveQRIS}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm"
                >
                  Simpan QRIS
                </button>
                <button
                  onClick={() => setEditingEmail(null)}
                  className="px-4 py-2 bg-gray-400 hover:bg-gray-500 text-white rounded-lg text-sm"
                >
                  Batal
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};