import { useState, useCallback } from 'react';
import { parseQRIS, convertQRIS, validateQRIS } from '@core/index';
import type { QRISData, ConvertOptions } from '@core/types';
import { Header } from '../components/Header';
import { QRISInput } from '../components/QRISInput';
import { QRISInfo } from '../components/QRISInfo';
import { ConvertForm } from '../components/ConvertForm';
import { QRISResult } from '../components/QRISResult';
import { Footer } from '../components/Footer';
import { useAuth } from '../contexts/AuthContext';

export const QRISMain = () => {
  const { user, logout, updateQRIS, getUserQRIS, getApiKey } = useAuth();
  const [qrisString, setQrisString] = useState('');
  const [parsed, setParsed] = useState<QRISData | null>(null);
  const [errors, setErrors] = useState<string[]>([]);
  const [result, setResult] = useState('');
  const [uploadStatus, setUploadStatus] = useState('');

  const apiKey = getApiKey();

  const handleQRISInput = useCallback((value: string) => {
    setQrisString(value);
    setResult('');
    setErrors([]);
    setParsed(null);
    setUploadStatus('');
    if (!value.trim()) return;
    const validation = validateQRIS(value.trim());
    if (!validation.valid) {
      setErrors(validation.errors);
      return;
    }
    try {
      const data = parseQRIS(value.trim());
      setParsed(data);
    } catch {
      setErrors(['Gagal parsing QRIS']);
    }
  }, []);

  const handleConvert = useCallback(
    (options: ConvertOptions) => {
      if (!qrisString.trim()) return;
      try {
        const converted = convertQRIS(qrisString.trim(), options);
        setResult(converted);
      } catch {
        setErrors(['Gagal konversi QRIS']);
      }
    },
    [qrisString]
  );

  const handleReset = useCallback(() => {
    setQrisString('');
    setParsed(null);
    setErrors([]);
    setResult('');
    setUploadStatus('');
  }, []);

  const handleSaveQRIS = () => {
    if (!qrisString.trim()) {
      setUploadStatus('Tidak ada QRIS untuk disimpan.');
      return;
    }
    const validation = validateQRIS(qrisString.trim());
    if (!validation.valid) {
      setUploadStatus('QRIS tidak valid: ' + validation.errors.join(', '));
      return;
    }
    updateQRIS(qrisString.trim());
    setUploadStatus('✅ QRIS statis berhasil disimpan ke akun!');
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 w-full max-w-2xl mx-auto px-4 py-8 space-y-6">
        <div className="bg-white dark:bg-gray-900 p-4 rounded-lg shadow border border-gray-200 dark:border-gray-700 space-y-2">
          <div className="flex justify-between items-center">
            <span className="font-medium">👋 Halo, {user?.name}</span>
            <button
              onClick={logout}
              className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg text-sm font-semibold transition"
            >
              Logout
            </button>
          </div>

          {/* Tampilan API Key */}
          <div className="mt-2 pt-2 border-t border-gray-200 dark:border-gray-700">
            <p className="text-sm"><strong className="text-gray-700 dark:text-gray-300">🔑 API Key:</strong></p>
            <div className="flex items-center gap-2 mt-1">
              <code className="bg-gray-100 dark:bg-gray-800 px-3 py-1.5 rounded-lg text-xs font-mono break-all flex-1">
                {apiKey || 'Belum tersedia (registrasi ulang)'}
              </code>
              {apiKey && (
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(apiKey);
                    alert('✅ API Key berhasil disalin!');
                  }}
                  className="px-3 py-1.5 bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 rounded-lg text-xs font-medium transition"
                >
                  Salin
                </button>
              )}
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              Gunakan key ini di web lain: <code className="bg-gray-100 dark:bg-gray-800 px-1.5 py-0.5 rounded text-xs">?key={apiKey || '...'}</code>
            </p>
          </div>
        </div>

        <QRISInput
          value={qrisString}
          onChange={handleQRISInput}
          onReset={handleReset}
          errors={errors}
        />

        {parsed && !errors.length && (
          <div className="flex items-center gap-4">
            <button
              onClick={handleSaveQRIS}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-semibold transition"
            >
              Simpan QRIS Statis ini ke Akun
            </button>
            {uploadStatus && (
              <span className={`text-sm ${uploadStatus.includes('✅') ? 'text-green-600' : 'text-red-600'}`}>
                {uploadStatus}
              </span>
            )}
          </div>
        )}

        {parsed && (
          <>
            <QRISInfo data={parsed} />
            <ConvertForm parsed={parsed} onConvert={handleConvert} />
          </>
        )}
        {result && <QRISResult qrisString={result} />}
      </main>
      <Footer />
    </div>
  );
};