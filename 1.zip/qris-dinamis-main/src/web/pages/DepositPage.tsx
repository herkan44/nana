import { useState, useEffect, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import { convertQRIS, validateQRIS } from '@core/index';
import QRCode from 'qrcode';

export const DepositPage = () => {
  const [searchParams] = useSearchParams();
  const apiKey = searchParams.get('key');
  const [amount, setAmount] = useState('');
  const [qrisString, setQrisString] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [qrisStatic, setQrisStatic] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // State untuk timer
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [isExpired, setIsExpired] = useState<boolean>(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Ambil QRIS statis berdasarkan API Key
  useEffect(() => {
    if (apiKey) {
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const user = users.find((u: any) => u.apiKey === apiKey);
      if (user && user.qrisStatic) {
        setQrisStatic(user.qrisStatic);
        setError('');
      } else {
        setError('QRIS statis tidak ditemukan untuk API Key ini');
        setQrisStatic(null);
      }
    } else {
      setError('Parameter key tidak ditemukan (contoh: ?key=...)');
      setQrisStatic(null);
    }
  }, [apiKey]);

  // Generate QR code ke canvas setiap kali qrisString berubah
  useEffect(() => {
    if (qrisString && canvasRef.current) {
      QRCode.toCanvas(canvasRef.current, qrisString, {
        width: 280,
        margin: 2,
        color: { dark: '#000000', light: '#FFFFFF' },
        errorCorrectionLevel: 'M',
      });
    }
  }, [qrisString]);

  // Timer countdown
  useEffect(() => {
    if (timeLeft > 0 && !isExpired) {
      timerRef.current = setTimeout(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && qrisString) {
      // Timer habis, set expired
      setIsExpired(true);
      // Hapus QR code dari canvas
      if (canvasRef.current) {
        const ctx = canvasRef.current.getContext('2d');
        if (ctx) ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
      }
    }
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [timeLeft, isExpired, qrisString]);

  // Reset timer dan expired saat generate ulang
  const resetTimer = () => {
    if (timerRef.current) clearTimeout(timerRef.current);
    setTimeLeft(120); // 2 menit
    setIsExpired(false);
  };

  const handleGenerate = () => {
    setError('');
    setQrisString('');
    setIsExpired(false);
    setTimeLeft(0);
    if (timerRef.current) clearTimeout(timerRef.current);

    const nominal = parseInt(amount);
    if (!amount || isNaN(nominal) || nominal <= 0) {
      setError('Masukkan nominal yang valid (contoh: 50000)');
      return;
    }
    if (!qrisStatic) {
      setError('QRIS statis tidak tersedia');
      return;
    }
    setLoading(true);
    try {
      const validation = validateQRIS(qrisStatic);
      if (!validation.valid) {
        setError('QRIS statis tidak valid: ' + validation.errors.join(', '));
        setLoading(false);
        return;
      }
      const converted = convertQRIS(qrisStatic, { amount: nominal });
      setQrisString(converted);
      resetTimer(); // Mulai timer setelah QR code muncul
    } catch (err) {
      setError('Gagal generate QRIS');
    } finally {
      setLoading(false);
    }
  };

  // Format waktu ke MM:SS
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Progress bar (0-100%)
  const progress = timeLeft > 0 ? (timeLeft / 120) * 100 : 0;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white dark:bg-gray-900 rounded-xl shadow-lg p-6 space-y-4">
        <h2 className="text-2xl font-bold text-center text-gray-900 dark:text-white">HK PAY</h2>
        
        {error && (
          <div className="bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 p-3 rounded-lg text-sm">
            {error}
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Jumlah (Rp)
          </label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="50000"
            className="w-full px-4 py-2 border rounded-lg dark:bg-gray-800 dark:border-gray-700 focus:ring-2 focus:ring-blue-500 outline-none"
            min="1"
          />
        </div>

        <button
          onClick={handleGenerate}
          disabled={loading || !qrisStatic}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? 'Memproses...' : 'Generate QRIS'}
        </button>

        {qrisString && !isExpired && (
          <div className="border-t dark:border-gray-700 pt-4 space-y-3">
            <div className="text-center">
              <h3 className="font-medium text-gray-700 dark:text-gray-300">Dynamic QRIS Result</h3>
              <div className="flex justify-center mt-2">
                <canvas ref={canvasRef} style={{ width: 200, height: 200 }} />
              </div>
              <p className="text-xl font-bold text-gray-900 dark:text-white mt-2">
                Rp {parseInt(amount).toLocaleString('id-ID')}
              </p>
            </div>

            {/* Timer & Progress Bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400">
                <span>⏳ Kadaluarsa dalam</span>
                <span className="font-mono font-bold">{formatTime(timeLeft)}</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                <div
                  className="bg-blue-600 h-2.5 rounded-full transition-all duration-1000"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          </div>
        )}

        {isExpired && (
          <div className="border-t dark:border-gray-700 pt-4 text-center">
            <div className="bg-yellow-50 dark:bg-yellow-900/20 text-yellow-700 dark:text-yellow-400 p-3 rounded-lg text-sm">
              ⏰ QR Code telah kadaluarsa. Silakan generate ulang.
            </div>
          </div>
        )}

        <p className="text-center text-xs text-gray-400 dark:text-gray-600">
          Masukan jumlah nominal untuk generate QRIS dinamis. QRIS ini hanya berlaku selama 2 menit.
        </p>
      </div>
    </div>
  );
};