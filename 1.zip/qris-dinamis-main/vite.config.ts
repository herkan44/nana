import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { resolve } from "path";

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@core": resolve(__dirname, "src/core"),
      "@web": resolve(__dirname, "src/web"),
    },
  },
  server: {
    host: "0.0.0.0", // Biarkan akses dari IP manapun (untuk development)
    port: 5173,
    cors: {
      origin: "*", // Izinkan semua domain mengakses (untuk iframe)
      methods: ["GET", "POST", "OPTIONS"],
      allowedHeaders: ["Content-Type", "Authorization"],
    },
  },
});